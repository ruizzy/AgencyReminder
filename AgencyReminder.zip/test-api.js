const axios = require('axios');

const apiKey = 'sk-uaqfruxihvethytbdxopnljjzevypciepuhcmsgjjykerqdk';
const apiUrl = 'https://api.siliconflow.cn/v1/chat/completions';

async function testAPI() {
  console.log('测试硅基流动 API...\n');

  try {
    const response = await axios.post(apiUrl, {
      model: 'Qwen/Qwen2.5-7B-Instruct',
      messages: [{
        role: 'user',
        content: 'Hello, just say "API works!" in Chinese'
      }],
      temperature: 0.7
    }, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      }
    });

    console.log('✅ API 调用成功！');
    console.log('\n模型响应:');
    console.log(response.data.choices[0].message.content);
    console.log('\n完整响应:');
    console.log(JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.error('❌ API 调用失败！');
    console.error('错误状态码:', error.response?.status);
    console.error('错误信息:', error.response?.data || error.message);
  }
}

testAPI();